﻿using Belatrix.JobLogger.CrossCutting.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.Business.Services
{
    public interface IBCLoggerManager
    {
        void LogMessage(bool logToConsole, bool logToFile, bool logToDataBase, bool logMessage, bool logWarning, bool logError, string message, MessageType messageType);
    }
}
