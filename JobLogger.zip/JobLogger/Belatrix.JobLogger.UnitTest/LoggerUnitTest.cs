﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Belatrix.JobLogger.Application.Services;
using Belatrix.JobLogger.CrossCutting.IoC;
using Belatrix.JobLogger.Domain.Models;
using Belatrix.JobLogger.CrossCutting.Common;

namespace Belatrix.JobLogger.UnitTest
{
    [TestClass]
    public class LoggerUnitTest
    {
        private readonly Lazy<ILoggerManagerApplication> loggerManagerApplication;
        public ILoggerManagerApplication LoggerManagerApplication
        {
            get
            {
                return loggerManagerApplication.Value;
            }
        }

        public LoggerUnitTest()
        {
            loggerManagerApplication = new Lazy<ILoggerManagerApplication>(() => IoCUnityContainer.CreateObject<ILoggerManagerApplication>());
        }

        #region Log Only Message
        [TestMethod]
        public void LogMessageOnlyToConsole()
        {
            Message message = new Message(){
                Valor = "Mensaje de Prueba",
                MessageType = MessageType.Message
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = true,
                LogToFile = false,
                LogToDataBase = false,

                LogMessage = true,
                LogError = false,
                LogWarning = false
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);

            Assert.AreEqual(true, status.Success);
        }
        
        [TestMethod]
        public void LogMessageOnlyToFile()
        {
            Message message = new Message()
            {
                Valor = "Mensaje de Prueba",
                MessageType = MessageType.Message
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = false,
                LogToFile = true,
                LogToDataBase = false,

                LogMessage = true,
                LogError = false,
                LogWarning = false
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);

            Assert.AreEqual(true, status.Success);
        }

        [TestMethod]
        public void LogMessageOnlyToDataBase()
        {
            Message message = new Message()
            {
                Valor = "Mensaje de Prueba",
                MessageType = MessageType.Message
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = false,
                LogToFile = false,
                LogToDataBase = true,

                LogMessage = true,
                LogError = false,
                LogWarning = false
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);

            Assert.AreEqual(true, status.Success);
        }

        #endregion

        #region Log Only Warning
        [TestMethod]
        public void LogWarningOnlyToConsole()
        {
            Message message = new Message()
            {
                Valor = "Warning de Prueba",
                MessageType = MessageType.Warning
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = true,
                LogToFile = false,
                LogToDataBase = false,

                LogMessage = false,
                LogError = false,
                LogWarning = true
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);
            Assert.AreEqual(true, status.Success);
        }

        [TestMethod]
        public void LogWarningOnlyToFile()
        {
            Message message = new Message()
            {
                Valor = "Warning de Prueba",
                MessageType = MessageType.Warning
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = false,
                LogToFile = true,
                LogToDataBase = false,

                LogMessage = false,
                LogError = false,
                LogWarning = true
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);
            Assert.AreEqual(true, status.Success);
        }

        [TestMethod]
        public void LogWarningOnlyToDataBase()
        {
            Message message = new Message()
            {
                Valor = "Mensaje de Prueba",
                MessageType = MessageType.Warning
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = false,
                LogToFile = false,
                LogToDataBase = true,

                LogMessage = false,
                LogError = false,
                LogWarning = true
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);
            Assert.AreEqual(true, status.Success);
        }

        #endregion

        #region Log Only Error
        [TestMethod]
        public void LogErrorOnlyToConsole()
        {
            Message message = new Message()
            {
                Valor = "Error de Prueba",
                MessageType = MessageType.Error
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = true,
                LogToFile = false,
                LogToDataBase = false,

                LogMessage = false,
                LogError = true,
                LogWarning = false
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);
            Assert.AreEqual(true, status.Success);
        }

        [TestMethod]
        public void LogErrorOnlyToFile()
        {
            Message message = new Message()
            {
                Valor = "Error de Prueba",
                MessageType = MessageType.Error
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = false,
                LogToFile = true,
                LogToDataBase = false,

                LogMessage = false,
                LogError = true,
                LogWarning = false
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);
            Assert.AreEqual(true, status.Success);
        }

        [TestMethod]
        public void LogErrorOnlyToDataBase()
        {
            Message message = new Message()
            {
                Valor = "Mensaje de Prueba",
                MessageType = MessageType.Error
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = false,
                LogToFile = false,
                LogToDataBase = true,

                LogMessage = false,
                LogError = true,
                LogWarning = false
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);
            Assert.AreEqual(true, status.Success);
        }

        #endregion

        [TestMethod]
        public void LogMessageAllLogs()
        {
            Message message = new Message()
            {
                Valor = "Mensaje de Prueba",
                MessageType = MessageType.Message
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = true,
                LogToFile = true,
                LogToDataBase = true,

                LogMessage = true,
                LogError = false,
                LogWarning = false
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);
            Assert.AreEqual(true, status.Success);
        }

        [TestMethod]
        public void LogWarningAllLogs()
        {
            Message message = new Message()
            {
                Valor = "Mensaje de Prueba",
                MessageType = MessageType.Warning
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = true,
                LogToFile = true,
                LogToDataBase = true,

                LogMessage = false,
                LogError = false,
                LogWarning = true
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);
            Assert.AreEqual(true, status.Success);
        }

        [TestMethod]
        public void LogErrorAllLogs()
        {
            Message message = new Message()
            {
                Valor = "Mensaje de Prueba",
                MessageType = MessageType.Error
            };

            LoggerConfiguration loggerConfiguration = new LoggerConfiguration
            {
                LogToConsole = true,
                LogToFile = true,
                LogToDataBase = true,

                LogMessage = false,
                LogError = true,
                LogWarning = false
            };

            StatusLog status = LoggerManagerApplication.LogMessage(message, loggerConfiguration);
            Assert.AreEqual(true, status.Success);
        }
    }
}
