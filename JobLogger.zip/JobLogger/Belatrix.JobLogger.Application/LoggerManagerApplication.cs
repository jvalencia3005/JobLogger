﻿using Belatrix.JobLogger.Application.Services;
using Belatrix.JobLogger.Business.Services;
using Belatrix.JobLogger.CrossCutting.IoC;
using Belatrix.JobLogger.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.Application.Components
{
    public class LoggerManagerApplication : ILoggerManagerApplication
    {
        private readonly Lazy<IBCLoggerManager> loggerManagerProvider;

        public LoggerManagerApplication()
        {
            loggerManagerProvider = new Lazy<IBCLoggerManager>(() => IoCUnityContainer.CreateObject<IBCLoggerManager>());
        }

        public IBCLoggerManager LoggerManagerProvider
        {
            get
            {
                return loggerManagerProvider.Value;
            }
        }

        public StatusLog LogMessage(Message message, LoggerConfiguration loggerConfiguration)
        {
            StatusLog status = new StatusLog();
            try
            {
                LoggerManagerProvider.LogMessage(loggerConfiguration.LogToConsole, loggerConfiguration.LogToFile, loggerConfiguration.LogToDataBase,
                                              loggerConfiguration.LogMessage, loggerConfiguration.LogWarning, loggerConfiguration.LogError,
                                              message.Valor, message.MessageType);
                status.Success = true;
                status.Message = "Se realizó el Log según la configuración correctamente.";
            }
            catch(Exception ex)
            {
                status.Success = false;
                status.Message = ex.Message;
            }

            return status;
        }

    }
}
