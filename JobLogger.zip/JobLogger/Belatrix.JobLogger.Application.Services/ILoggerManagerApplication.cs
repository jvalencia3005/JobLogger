﻿using Belatrix.JobLogger.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.Application.Services
{
    public interface ILoggerManagerApplication
    {
        StatusLog LogMessage(Message message, LoggerConfiguration loggerConfiguration);
    }
}
