﻿using Belatrix.JobLogger.Application.Services;
using Belatrix.JobLogger.CrossCutting.Common;
using Belatrix.JobLogger.CrossCutting.IoC;
using Belatrix.JobLogger.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobLogger
{
    class Program
    {
        private static readonly Lazy<ILoggerManagerApplication> loggerManagerApplication = new Lazy<ILoggerManagerApplication>(() => IoCUnityContainer.CreateObject<ILoggerManagerApplication>());
        public static ILoggerManagerApplication LoggerManagerApplication
        {
            get
            {
                return loggerManagerApplication.Value;
            }
        }
        static void Main(string[] args)
        {
            Message message = new Message();
            LoggerConfiguration loggerConfiguration = new LoggerConfiguration();

            bool setLoggerConfiguration = false;
            string configureAgain = string.Empty;
            string exitApp = "N";

            while (exitApp.ToUpper() != "S")
            {
                exitApp = string.Empty;
                while (!string.Equals(configureAgain.ToUpper(), "S") && !string.Equals(configureAgain.ToUpper(), "N"))
                {
                    Console.WriteLine("Desea realizar la configuración (S/N):");
                    configureAgain = Console.ReadLine();
                }

                setLoggerConfiguration = string.Equals(configureAgain.ToUpper(), "S");
                while (setLoggerConfiguration)
                {
                    SetLoggerConfiguration(loggerConfiguration);
                    setLoggerConfiguration = false;
                }

                LogMessage(message, loggerConfiguration);
                

                while (!string.Equals(exitApp.ToUpper(), "S") && !string.Equals(exitApp.ToUpper(), "N"))
                {
                    Console.WriteLine("Desea salir de la aplicación (S/N):");
                    exitApp = Console.ReadLine();
                }

                configureAgain = string.Empty;
            }
        }

        private static void SetLoggerConfiguration(LoggerConfiguration loggerConfiguration)
        {
            string logToConsole = string.Empty;
            string logToDataBase = string.Empty;
            string logToFile = string.Empty;

            string logMessage = string.Empty;
            string logWarning = string.Empty;
            string logError = string.Empty;

            Console.WriteLine("Ingrese la configuración:");

            while (!string.Equals(logToConsole.ToUpper(), "S") && !string.Equals(logToConsole.ToUpper(), "N"))
            {
                Console.WriteLine("Desea logear en consola? (S/N):");
                logToConsole = Console.ReadLine();
            }

            while (!string.Equals(logToFile.ToUpper(), "S") && !string.Equals(logToFile.ToUpper(), "N"))
            {
                Console.WriteLine("Desea logear en un archivo? (S/N):");
                logToFile = Console.ReadLine();
            }

            while (!string.Equals(logToDataBase.ToUpper(), "S") && !string.Equals(logToDataBase.ToUpper(), "N"))
            {
                Console.WriteLine("Desea logear en base de datos? (S/N):");
                logToDataBase = Console.ReadLine();
            }

            while (!string.Equals(logMessage.ToUpper(), "S") && !string.Equals(logMessage.ToUpper(), "N"))
            {
                Console.WriteLine("Desea logear los mensajes? (S/N):");
                logMessage = Console.ReadLine();
            }

            while (!string.Equals(logError.ToUpper(), "S") && !string.Equals(logError.ToUpper(), "N"))
            {
                Console.WriteLine("Desea logear los errores? (S/N):");
                logError = Console.ReadLine();
            }

            while (!string.Equals(logWarning.ToUpper(), "S") && !string.Equals(logWarning.ToUpper(), "N"))
            {
                Console.WriteLine("Desea logear los warnings? (S/N):");
                logWarning = Console.ReadLine();
            }

            loggerConfiguration.LogToConsole = string.Equals(logToConsole.ToUpper(), "S");
            loggerConfiguration.LogToFile = string.Equals(logToFile.ToUpper(), "S");
            loggerConfiguration.LogToDataBase = string.Equals(logToDataBase.ToUpper(), "S");

            loggerConfiguration.LogMessage = string.Equals(logMessage.ToUpper(), "S");
            loggerConfiguration.LogError = string.Equals(logError.ToUpper(), "S");
            loggerConfiguration.LogWarning = string.Equals(logWarning.ToUpper(), "S");
        }

        private static void LogMessage(Message message, LoggerConfiguration loggerConfiguration)
        {
            Console.WriteLine("Escriba el mensaje: ");
            message.Valor = Console.ReadLine();

            string messageType = string.Empty;
            while (!string.Equals(messageType.ToUpper(), "1") && !string.Equals(messageType.ToUpper(), "2") && !string.Equals(messageType.ToUpper(), "3")) 
            {
                Console.WriteLine("Escriba el Tipo de Mensaje (1 = Message, 2 = Error, 3=Warning)");
                messageType = Console.ReadLine();
            }

            switch (messageType)
            {
                case "1": message.MessageType = MessageType.Message;
                    break;
                case "2": message.MessageType = MessageType.Error;
                    break;
                case "3": message.MessageType = MessageType.Warning;
                    break;
            }

            LoggerManagerApplication.LogMessage(message, loggerConfiguration);
        }
    }
}
