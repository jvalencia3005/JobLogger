﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.CrossCutting.IoC
{
    public class IoCUnityContainer
    {
        protected static readonly Lazy<IoCUnityContainer> instance = new Lazy<IoCUnityContainer>(() => new IoCUnityContainer(), true);

        private IUnityContainer container;

        private IoCUnityContainer()
        {
            CreateUnityContainer();
        }

        internal static IoCUnityContainer Current
        {
            get { return instance.Value; }
        }

        public const string SectionName = "unity";
        public const string ConfigurationFileName = "UnityConfiguration.config";

        private void CreateUnityContainer()
        {
            container = new UnityContainer();
            container.LoadConfiguration();
        }

        private void DisposeUnityContainer()
        {
            if (container != null)
            {
                container.Dispose();
            }
        }

        private T Create<T>()
        {
            return container.Resolve<T>();
        }

        public static void BuildContainer()
        {
            IoCUnityContainer.Current.CreateUnityContainer();
        }

        public static void DisposeContainer()
        {
            IoCUnityContainer.Current.DisposeUnityContainer();
        }


        /// <summary>
        /// Creates the object.
        /// </summary>
        /// <typeparam name="T">The type of object to be created</typeparam>
        /// <returns>A new T object</returns>
        public static T CreateObject<T>()
        {
            return IoCUnityContainer.Current.Create<T>();
        }
    }
}
