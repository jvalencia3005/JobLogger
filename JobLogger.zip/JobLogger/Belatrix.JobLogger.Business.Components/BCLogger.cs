﻿using Belatrix.JobLogger.Business.Services;
using Belatrix.JobLogger.CrossCutting.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.Business.Components
{
    public abstract class BCLogger : IBCLogger
    {
        public abstract void LogMessage(string message, MessageType messageType);

    }
}
