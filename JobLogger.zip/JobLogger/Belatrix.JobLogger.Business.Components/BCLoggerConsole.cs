﻿using Belatrix.JobLogger.Business.Services;
using Belatrix.JobLogger.CrossCutting.Common;
using Belatrix.JobLogger.CrossCutting.IoC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.Business.Components
{
    public class BCLoggerConsole : BCLogger, IBCLoggerConsole
    {
        public override void LogMessage(string message, MessageType messageType)
        {
            var consoleColor = GetColor(messageType);
            var messageValue = String.Format("Fecha: {0}, Mensaje: {1}", DateTime.Now.ToLongDateString(), message);
            ConsoleWriter.WriteLine(messageValue, consoleColor);
        }

        private static ConsoleColor GetColor(MessageType messageType)
        {
            switch (messageType)
            {
                case MessageType.Message:
                    return ConsoleColor.White;
                case MessageType.Warning:
                    return ConsoleColor.Yellow;
                case MessageType.Error:
                    return ConsoleColor.Red;
                default:
                    throw new NotSupportedException("Tipo de mensaje no soportado");
            }
        }
    }
}
