﻿using Belatrix.JobLogger.Business.Services;
using Belatrix.JobLogger.CrossCutting.Common;
using Belatrix.JobLogger.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.Business.Components
{
    public class BCLoggerDataBase : BCLogger, IBCLoggerDataBase
    {
        private DAMessageLog messageLogProvider;

        protected DAMessageLog DAMessageLog
        {
            get
            {
                if (messageLogProvider == null)
                {
                    this.messageLogProvider = new DAMessageLog();
                }
                return this.messageLogProvider;
            }
        }

        public override void LogMessage(string message, MessageType messageType)
        {
            DAMessageLog.SaveMessage(message, (int)messageType);
        }
    }
}
