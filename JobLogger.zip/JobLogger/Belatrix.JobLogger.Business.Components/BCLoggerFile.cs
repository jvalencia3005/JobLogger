﻿using Belatrix.JobLogger.Business.Services;
using Belatrix.JobLogger.CrossCutting.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.Business.Components
{
    public class BCLoggerFile : BCLogger, IBCLoggerFile
    {
        public override void LogMessage(string message, MessageType messageType)
        {
            var fileName = String.Format("LogFile{0}.txt", DateTime.Now.ToString("dd-MM-yyyy"));

            if (!FileManager.ExistDirectory(Constant.AppSettings.LogDirectoryPath))
                FileManager.CreateDirectory(Constant.AppSettings.LogDirectoryPath);

            var filePath = Path.Combine(Constant.AppSettings.LogDirectoryPath, fileName);
            var logText = String.Format("Fecha Creacion: {0} - Tipo Mensaje: {1} - Mensaje: {2}", DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss"), messageType,
                message);

            FileManager.AppendTextToFile(filePath, logText);
        }
    }
}
