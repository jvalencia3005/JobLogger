﻿using Belatrix.JobLogger.Business.Services;
using Belatrix.JobLogger.CrossCutting.Common;
using Belatrix.JobLogger.CrossCutting.IoC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.Business.Components
{
    public class BCLoggerManager : IBCLoggerManager
    {
        private readonly Lazy<IBCLoggerConsole> loggerConsoleProvider;
        private readonly Lazy<IBCLoggerFile> loggerFileProvider;
        private readonly Lazy<IBCLoggerDataBase> loggerDataBaseProvider;

        public BCLoggerManager()
        {
            loggerConsoleProvider = new Lazy<IBCLoggerConsole>(() => IoCUnityContainer.CreateObject<IBCLoggerConsole>());
            loggerFileProvider = new Lazy<IBCLoggerFile>(() => IoCUnityContainer.CreateObject<IBCLoggerFile>());
            loggerDataBaseProvider = new Lazy<IBCLoggerDataBase>(() => IoCUnityContainer.CreateObject<IBCLoggerDataBase>());
        }

        public IBCLoggerConsole LoggerConsoleProvider
        {
            get
            {
                return loggerConsoleProvider.Value;
            }
        }

        public IBCLoggerFile LoggerFileProvider
        {
            get
            {
                return loggerFileProvider.Value;
            }
        }

        public IBCLoggerDataBase LoggerDataBaseProvider
        {
            get
            {
                return loggerDataBaseProvider.Value;
            }
        }

        public void LogMessage(bool logToConsole, bool logToFile, bool logToDataBase, bool logMessage, bool logWarning, bool logError, string message, MessageType messageType)
        {
            if (logMessage && messageType == MessageType.Message)
            {
                LogMessage(logToConsole, logToFile, logToDataBase, message, messageType);
            }

            if (logWarning && messageType == MessageType.Warning)
            {
                LogMessage(logToConsole, logToFile, logToDataBase, message, messageType);
            }

            if (logError && messageType == MessageType.Error)
            {
                LogMessage(logToConsole, logToFile, logToDataBase, message, messageType);
            }
            
        }

        private void LogMessage(bool logToConsole, bool logToFile, bool logToDataBase, string message, MessageType messageType)
        {
            if (logToConsole)
            {
                LoggerConsoleProvider.LogMessage(message, messageType);
            }

            if (logToFile)
            {
                LoggerFileProvider.LogMessage(message, messageType);
            }

            if (logToDataBase)
            {
                LoggerDataBaseProvider.LogMessage(message, messageType);
            }
        }
    }
}
