﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.DataAccess
{
    public static class Connection
    {
        private static SqlConnection instance = null;
        private static readonly object lockInstance = new object();
        private static readonly string connectionString = ConfigurationManager.ConnectionStrings["LogDatabase"].ConnectionString;

        public static SqlConnection GetDBInstance
        {
            get
            {
                lock (lockInstance)
                {
                    if (instance == null)
                        instance = new SqlConnection(connectionString);
                    return instance;
                }
            }
        }
        public static void Open()
        {
            if (instance != null)
                instance.Open();
        }
        public static void Close()
        {
            if (instance != null)
                instance.Close();
        }
    }
}

