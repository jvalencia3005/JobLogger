﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.DataAccess
{
    public class DAMessageLog
    {
        public void SaveMessage(string message, int messageType)
        {
            var connection = Connection.GetDBInstance;

            using (SqlCommand cmd = new SqlCommand()) {
                cmd.CommandText = "spuMessageLogInsert";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = connection;
                cmd.Parameters.AddWithValue("@Message", message);
                cmd.Parameters.AddWithValue("@MessageType", messageType);

                try
                {

                    connection.Open();              
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (connection.State != System.Data.ConnectionState.Closed)
                        connection.Close();
                }
            }}
        }
}