﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.CrossCutting.Common
{
    public struct Constant
    {
        #region appSettings

        public struct AppSettings
        {
            public static string LogDirectoryPath = ConfigurationManager.AppSettings["LogDirectoryPath"];
        }

        #endregion
    }
}
