﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belatrix.JobLogger.CrossCutting.Common
{
    public static class FileManager
    {
        public static bool ExistDirectory(string logDirectoryPath)
        {
            return Directory.Exists(logDirectoryPath);
        }

        public static void AppendTextToFile(string filePath, string text)
        {
            using (var streamWriter = File.AppendText(filePath))
            {
                streamWriter.WriteLine(text);
            }
        }

        public static void CreateDirectory(string logDirectoryPath)
        {
            Directory.CreateDirectory(logDirectoryPath);
        }
    }
}
